package wtf.temmie.XYZUtils.commands;

import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;

import wtf.temmie.XYZUtils.XYZUtils;

public class XYZCommand implements CommandExecutor {

	public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
		switch(args.length) {
			case 0: {
				// Display help
				break;
			}
			case 1: {
				if(args[0].equalsIgnoreCase("reload")) {
					XYZUtils.instance.mentionsEnabled = XYZUtils.instance.getConfig().getBoolean("mentions");
					XYZUtils.instance.itemEnabled = XYZUtils.instance.getConfig().getBoolean("item");
				}
			}
		}
		
		return true;
	}

}
